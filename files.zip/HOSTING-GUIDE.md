# Hosting the Lead Performance Calculator — Step by Step

Everything here happens in a browser tab. No downloads, no installs, no terminal.
You'll set up three free accounts and connect them together. Total time: about 45 minutes the first time.

The three pieces, and what each does:
- **GitHub** — holds the code (think of it as the filing cabinet).
- **Supabase** — the database that stores all your data and lets every manager share it.
- **Vercel** — turns the code into a real website at a link you share.

When you're done, managers open one link (like `hollerclassic-lpc.vercel.app`) and that's it.

Do the parts in order. Each part hands something to the next.

---

## PART 1 — Put the code on GitHub (10 min)

1. Go to **github.com** and create a free account (or sign in).
2. Click the **+** in the top-right corner → **New repository**.
3. Name it `lead-performance-calculator`. Leave it **Public** (simpler; the code being visible is fine, your data lives in Supabase, not here). Check **"Add a README file."** Click **Create repository**.
4. Now you'll upload the project files. On your new repo page, click **Add file** → **Upload files**.
5. Drag in **all the files from the `lpc-host` folder** I gave you, *keeping the folder structure*. The easiest way: the `src` folder goes in as a folder, and the loose files (`package.json`, `vite.config.js`, `index.html`, `.gitignore`, `supabase-setup.sql`) go in at the top level.
   - If GitHub's uploader won't take a folder, create it: click **Add file → Create new file**, type `src/main.jsx` as the name (the `src/` makes the folder), paste that file's contents, commit. Repeat for `src/LeadPerformanceCalculator.jsx`.
6. Click **Commit changes**. Your code now lives on GitHub.

---

## PART 2 — Create the database in Supabase (10 min)

1. Go to **supabase.com** → **Start your project** → sign in (you can use your GitHub account to sign in, one less password).
2. Click **New project**. Give it a name (`lead-performance`), and set a database password (save it somewhere; you likely won't need it again, but don't lose it). Pick the region closest to Orlando (US East). Click **Create new project** and wait ~2 minutes for it to spin up.
3. When it's ready, open the **SQL Editor** (left sidebar, looks like a database icon).
4. Click **New query**, then open the `supabase-setup.sql` file I gave you, copy its entire contents, paste into the editor, and click **Run**. You should see "Success." This creates the table your app uses.
5. Now grab two values the website needs. Go to **Project Settings** (gear icon) → **API**.
   - Copy the **Project URL** (looks like `https://abcdefgh.supabase.co`). Save it.
   - Under **Project API keys**, copy the **`anon` `public`** key (a long string). Save it.
   - You'll paste both into Vercel in Part 3. Keep them handy.

---

## PART 3 — Publish the website with Vercel (10 min)

1. Go to **vercel.com** → **Sign Up** → **Continue with GitHub** (this links them automatically).
2. On your Vercel dashboard, click **Add New… → Project**.
3. You'll see your GitHub repos. Find `lead-performance-calculator` and click **Import**.
4. Vercel auto-detects it's a Vite project — you don't need to change the build settings.
5. Before deploying, expand **Environment Variables** and add these two (this is where your Supabase values go):
   - Name: `VITE_SUPABASE_URL` → Value: the Project URL you copied.
   - Name: `VITE_SUPABASE_ANON_KEY` → Value: the anon public key you copied.
6. Click **Deploy**. Wait ~1 minute. When it finishes, Vercel shows you a live link like `lead-performance-calculator.vercel.app`.
7. Click it. You should see the splash screen. **Set up your admin account right there** — this time it saves to the real database.

---

## PART 4 — First-time setup inside the tool (5 min)

1. On the live site, create your admin account (email + 6-digit PIN).
2. Sign in, go to the **Access** tab, add your approved email domain (e.g. `hollerclassic.com`).
3. Go to **Stores** and set up your stores, logos, and standards.
4. Send the link to one manager as a test. Have them open it, click **Create New Account**, and register. Approve them from your **Access** tab. Confirm they can sign in and only see their store.
5. Once that works, send the link to everyone.

That's it. Managers just open the link — no account with Claude, no download, nothing to install.

---

## Changing the custom URL (optional)

Vercel lets you rename the project to change the subdomain (e.g. `hollerclassic-lpc.vercel.app`):
Project → **Settings → Domains**, or **Settings → General → Project Name**.

---

## How updates work from here on

When you want a change, I give you an updated `LeadPerformanceCalculator.jsx`. You:
1. Go to your GitHub repo → open `src/LeadPerformanceCalculator.jsx` → click the pencil (**Edit**) icon.
2. Select all, delete, paste the new version, click **Commit changes**.
3. Vercel notices the change and rebuilds automatically in about a minute.
4. Managers get the update the next time they refresh. No one redownloads anything.

That's the whole loop: I hand you a file, you paste it into GitHub, everyone's on the new version a minute later.

---

## If something doesn't work

- **Blank page after deploy** → usually the two environment variables are missing or misspelled in Vercel. Go to Project → Settings → Environment Variables, fix them, then Deployments → click the latest → **Redeploy**.
- **"Couldn't save your account"** → the Supabase table wasn't created. Re-run `supabase-setup.sql` in the SQL Editor.
- **Managers can't register** → make sure you added your approved domain in the Access tab and that their email matches it.
- **Leaderboard is blank on the TV** → the store has no data for the current month yet, or the TV's browser is blocking the pop-up. Allow pop-ups for the site.
